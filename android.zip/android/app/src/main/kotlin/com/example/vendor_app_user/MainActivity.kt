package com.example.vendor_app_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
